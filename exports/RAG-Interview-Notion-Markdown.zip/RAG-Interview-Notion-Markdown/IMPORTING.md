# Import into Notion

[Book index](README.md)

1. Download the dedicated RAG-Interview-Notion-Markdown.zip archive.
2. In the destination Notion workspace, open Settings → Import → Text & Markdown.
3. Select the ZIP to import the folder structure and Markdown pages.
4. Open the landing index, then Start here or Reading routes.
5. Check cross-page links, tables, equations, and diagrams after import.

This archive contains all 60 book pages, a landing index, this guide, and the
source-rights notice. It is a point-in-time copy, not a live synchronization.
Comments, permissions, page history, icons, and database configuration are not
included. Anchor links and tool-specific formatting may not import cleanly;
math and Mermaid rendering may need manual adjustment in Notion.

See Notion's current import documentation:
https://www.notion.so/help/import-data-into-notion

Source attribution and third-party rights remain unchanged. See NOTICE.md.
